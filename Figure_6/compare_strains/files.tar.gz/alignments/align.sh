nucmer ref/Escherichia_coli_UMN026_uid62981.fasta ref/Escherichia_coli_K_12_substr__MG1655_uid57779_A.fasta 
show-coords -TH out.delta  > out_umn026_k12
nucmer ref/Escherichia_coli_LF82_uid161965_B2.fasta ref/Escherichia_coli_UMN026_uid62981.fasta 
show-coords -TH out.delta  > out_lf82_umn026

